#!/bin/bash

for i in "$@"; do
    case $i in
        -h|--help)
            usage
            exit
            ;;
        --clusterid=?*)
            CLUSTERID=(${i#*=})
            echo "setting CLUSTERID=${CLUSTERID}"
            ;;
		--nodepool=?*)
            NODEPOOL=(${i#*=})
            echo "setting NODEPOOL=${NODEPOOL}"
            ;;
        --zone=?*)
            ZONE=${i#*=}
            echo "setting ZONE=${ZONE}"
            ;;
		--nodesaddr=?*)
            nodesaddr=(${i#*=})
            echo "setting nodesaddr=${nodesaddr[@]}"
            ;;
        --prefix=?*)
            VM_PREFIX=${i#*=}
            echo "setting prefix=${VM_PREFIX}"
            ;;
        --region=?*)
            REGION=${i#*=}
            echo "setting machine type=${REGION}"
            ;;
     esac
done

export VM_WS=${VM_PREFIX}-ws
gcloud compute ssh root@$VM_WS --zone ${ZONE} << EOF
set -x
export PROJECT_ID=$(gcloud config get-value project)
export clusterid=${CLUSTERID}
export NODESADDR=${nodesaddr}
echo ${nodesaddr[@]}
export REGION=${REGION}
cat > nodepool-$NODEPOOL.yaml << EOB
---
apiVersion: baremetal.cluster.gke.io/v1
kind: NodePool
metadata:
  name: $NODEPOOL
  namespace: cluster-\$clusterid
spec:
  clusterName: \$clusterid
  nodes: ${nodesaddr[@]}
 #nodes: [{address: 10.200.0.4},{address: 10.200.0.5}]
  #- address: 10.200.0.4
  #- address: 10.200.0.5
EOB
kubectl apply -f nodepool-$NODEPOOL.yaml
EOF