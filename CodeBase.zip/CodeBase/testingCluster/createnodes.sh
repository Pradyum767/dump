#!/bin/bash

for i in "$@"; do
    case $i in
        -h|--help)
            usage
            exit
            ;;
        --vms=?*)
            VMs=(${i#*=})
            echo "setting VMS=${VMs[@]}"
            ;;
		--newvms=?*)
            NEWVMs=(${i#*=})
            echo "setting NEWVMS=${NEWVMs[@]}"
            ;;
        --zone=?*)
            ZONE=${i#*=}
            echo "setting ZONE=${ZONE}"
            ;;
		--nodepool=?*)
            NODEPOOL=${i#*=}
            echo "setting NODEPOOL=${NODEPOOL}"
            ;;
        --prefix=?*)
            VM_PREFIX=${i#*=}
            echo "setting prefix=${VM_PREFIX}"
            ;;
        --machinetype=?*)
            MACHINE_TYPE=${i#*=}
            echo "setting machine type=${MACHINE_TYPE}"
            ;;
        --disksize=?*)
            DISK_SIZE=${i#*=}
            echo "setting disk size=${DISK_SIZE}"
            ;;
        --subnet1=?*)
            SUBNET1=${i#*=}
            echo "setting subnet1=${SUBNET1}"
            ;;
        --subnet2=?*)
            SUBNET2=${i#*=}
            echo "setting subnet2=${SUBNET2}"
            ;;
        --subnet3=?*)
            SUBNET3=${i#*=}
            echo "setting subnet3=${SUBNET3}"
            ;;
     esac
done

export PROJECT_ID=$(gcloud config get-value project)


#MACHINE_TYPE=e2-standard-4
#DISK_SIZE=100G
#VM_PREFIX=test-baremetal
#SUBNET1=default
#SUBNET2=multus-subnet3
VM_WS=$VM_PREFIX-ws
VM_CP=$VM_PREFIX-cp
#echo ${VMs[@]}
#VM_WN=$VM_PREFIX-wn
#declare -a VMs=("$VM_WS" "$VM_CP" )
declare -a IPs=()

# --image=projects/ubuntu-os-cloud/global/images/ubuntu-1804-bionic-v20220118 \

for vm in "${NEWVMs[@]}"
do
    gcloud compute instances create $vm \
              --image=projects/ubuntu-os-cloud/global/images/ubuntu-1804-bionic-v20220118 \
              --zone=${ZONE} \
              --boot-disk-size ${DISK_SIZE} \
              --boot-disk-type pd-ssd \
              --can-ip-forward \
              --network-interface=network-tier=PREMIUM,subnet=${SUBNET1} \
              --network-interface=network-tier=PREMIUM,subnet=${SUBNET2} \
			  --network-interface=network-tier=PREMIUM,subnet=${SUBNET3} \
              --tags http-server,https-server \
              --scopes cloud-platform \
              --machine-type ${MACHINE_TYPE}

done


for vm in "${VMs[@]}"
do

    IP=$(gcloud compute instances describe $vm --zone ${ZONE} \
         --format='get(networkInterfaces[0].networkIP)')
    IPs+=("$IP")
done


for vm in "${VMs[@]}"
do
    while ! gcloud compute ssh root@$vm --zone ${ZONE} --command "echo SSH to $vm succeeded"
    do
        echo "Trying to SSH into $vm failed. Sleeping for 5 seconds. zzzZZzzZZ"
        sleep  5
    done
done

i=2 # We start from 10.200.0.2/24
for vm in "${VMs[@]}"
do
    gcloud compute ssh root@$vm --zone ${ZONE} << EOF
        apt-get -qq update > /dev/null
        apt-get -qq install -y jq > /dev/null
        set -x
        ip link add vxlan0 type vxlan id 42 dev ens4 dstport 0
        current_ip=\$(ip --json a show dev ens4 | jq '.[0].addr_info[0].local' -r)
        echo "VM IP address is: \$current_ip"
        for ip in ${IPs[@]}; do
            if [ "\$ip" != "\$current_ip" ]; then
                bridge fdb append to 00:00:00:00:00:00 dst \$ip dev vxlan0
            fi
        done
        ip addr add 10.200.0.$i/24 dev vxlan0
        ip link set up dev vxlan0

EOF
    i=$((i+1))
done

gcloud compute ssh root@$VM_WS --zone ${ZONE} << EOF
set -x
sed 's/ssh-rsa/root:ssh-rsa/' ~/.ssh/id_rsa.pub > ssh-metadata
for vm in ${VMs[@]}
do
    gcloud compute instances add-metadata \$vm --zone ${ZONE} --metadata-from-file ssh-keys=ssh-metadata
done
EOF

