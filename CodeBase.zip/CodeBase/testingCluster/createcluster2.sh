#!/bin/bash

for i in "$@"; do
    case $i in
        -h|--help)
            usage
            exit
            ;;
        --clusterid=?*)
            CLUSTERID=(${i#*=})
            echo "setting CLUSTERID=${CLUSTERID}"
            ;;
        --zone=?*)
            ZONE=${i#*=}
            echo "setting ZONE=${ZONE}"
            ;;
		--nodesaddr=?*)
            nodesaddr=(${i#*=})
            echo "setting nodesaddr=${nodesaddr[@]}"
            ;;
        --prefix=?*)
            VM_PREFIX=${i#*=}
            echo "setting prefix=${VM_PREFIX}"
            ;;
        --region=?*)
            REGION=${i#*=}
            echo "setting machine type=${REGION}"
            ;;
     esac
done

export VM_WS=${VM_PREFIX}-ws
gcloud compute ssh root@$VM_WS --zone ${ZONE} << EOF
set -x
export PROJECT_ID=$(gcloud config get-value project)
export clusterid=${CLUSTERID}
export NODESADDR=${nodesaddr}
echo ${nodesaddr[@]}
export REGION=${REGION}
bmctl create config -c \$clusterid
cat > bmctl-workspace/\$clusterid/\$clusterid.yaml << EOB
---
gcrKeyPath: /root/bm-gcr.json
sshPrivateKeyPath: /root/.ssh/id_rsa
gkeConnectAgentServiceAccountKeyPath: /root/bm-gcr.json
gkeConnectRegisterServiceAccountKeyPath: /root/bm-gcr.json
cloudOperationsServiceAccountKeyPath: /root/bm-gcr.json
---
apiVersion: v1
kind: Namespace
metadata:
  name: cluster-\$clusterid
---
apiVersion: baremetal.cluster.gke.io/v1
kind: Cluster
metadata:
  name: \$clusterid
  namespace: cluster-\$clusterid
spec:
  type: hybrid
  anthosBareMetalVersion: 1.10.0
  gkeConnect:
    projectID: \$PROJECT_ID
  controlPlane:
    nodePoolSpec:
      clusterName: \$clusterid
      nodes:
      - address: 10.200.0.3
  clusterNetwork:
    multipleNetworkInterfaces: true
    pods:
      cidrBlocks:
      - 192.168.0.0/16
    services:
      cidrBlocks:
      - 172.26.232.0/24
  loadBalancer:
    mode: bundled
    ports:
      controlPlaneLBPort: 443
    vips:
      controlPlaneVIP: 10.200.0.49
      ingressVIP: 10.200.0.50
    addressPools:
    - name: pool1
      addresses:
      - 10.200.0.50-10.200.0.70
  clusterOperations:
    # might need to be this location
    location: \$REGION
    projectID: \$PROJECT_ID
  storage:
    lvpNodeMounts:
      path: /mnt/localpv-disk
      storageClassName: node-disk
    lvpShare:
      numPVUnderSharedPath: 5
      path: /mnt/localpv-share
      storageClassName: standard
  nodeConfig:
    podDensity:
      maxPodsPerNode: 250
    containerRuntime: containerd
---
apiVersion: baremetal.cluster.gke.io/v1
kind: NodePool
metadata:
  name: node-pool-1
  namespace: cluster-\$clusterid
spec:
  clusterName: \$clusterid
  nodes: ${nodesaddr[@]}
 #nodes: [{address: 10.200.0.4},{address: 10.200.0.5}]
  #- address: 10.200.0.4
  #- address: 10.200.0.5
EOB
cat bmctl-workspace/\$clusterid/\$clusterid.yaml
bmctl create cluster -c \$clusterid
EOF


gcloud compute ssh root@$VM_WS --zone ${ZONE} << EOF
set -x
export PROJECT_ID=$(gcloud config get-value project)
export clusterid=${CLUSTERID}
export REGION=${REGION}
cp ~/bmctl-workspace/\$clusterid/\$clusterid-kubeconfig .kube/config

cat <<EOB > /tmp/impersonate.yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: gateway-impersonate
rules:
- apiGroups:
  - ""
  resourceNames:
  - aaditya.garg@cognizant.com
  - aayush.bansal@cognizant.com
  - mohammedashir.hassan@cognizant.com
  - navaneethakrishnan.l@cognizant.com
  - nirmalgopi.r@cognizant.com
  - pradyum.kumarsingh@cognizant.com
  - 216748727601-compute@developer.gserviceaccount.com
  resources:
  - users
  verbs:
  - impersonate
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: gateway-impersonate
roleRef:
  kind: ClusterRole
  name: gateway-impersonate
  apiGroup: rbac.authorization.k8s.io
subjects:
- kind: ServiceAccount
  name: connect-agent-sa
  namespace: gke-connect
EOB
# Apply impersonation policy to the cluster.
kubectl apply -f /tmp/impersonate.yaml

cat <<EOB > /tmp/admin-permission.yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: gateway-cluster-admin
subjects:
- kind: User
  name: 216748727601-compute@developer.gserviceaccount.com
- kind: User
  name: aayush.bansal@cognizant.com
- kind: User
  name: navaneethakrishnan.l@cognizant.com
- kind: User
  name: nirmalgopi.r@cognizant.com
- kind: User
  name: aaditya.garg@cognizant.com
- kind: User
  name: pradyum.kumarsingh@cognizant.com
- kind: User
  name: mohammedashir.hassan@cognizant.com
roleRef:
  kind: ClusterRole
  name: cluster-admin
  apiGroup: rbac.authorization.k8s.io
EOB
# Apply permission policy to the cluster.
kubectl apply -f /tmp/admin-permission.yaml
EOF
