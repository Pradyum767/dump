#!/bin/bash
export WS=$1
export ZONE=$2
export WN=$3

gcloud compute ssh root@$WN --zone $ZONE  <<EOF
sudo apt install -y nfs-common
EOF

gcloud compute ssh root@$WS --zone $ZONE  <<EOF
cd ~
rm -r -f dep/ > /dev/null
git clone http://gerrit.o-ran-sc.org/r/it/dep -b bronze
cd dep
git submodule update --init --recursive --remote
cd tools/k8s/bin
./gen-cloud-init.sh
sed -i 's/2.12.3/2.17.0/g' k8s-1node-cloud-init-k_1_16-h_2_12-d_cur.sh
sed -i 's+https://storage.googleapis.com/kubernetes-helm/helm-+https://get.helm.sh/helm-+g' k8s-1node-cloud-init-k_1_16-h_2_12-d_cur.sh
cd ~/dep/ric-dep/helm/infrastructure/subcharts/kong
sed -i 's#kong-docker-kubernetes-ingress-controller.bintray.io/kong-ingress-controller#kong/kubernetes-ingress-controller#g' values.yaml
cd ~/dep/ric-aux/helm/infrastructure/subcharts/kong
sed -i 's#kong-docker-kubernetes-ingress-controller.bintray.io/kong-ingress-controller#kong/kubernetes-ingress-controller#g' values.yaml
cd ~/dep/ric-dep/helm/infrastructure
sed -i 's#gcr.io#ghcr.io#g' values.yaml
sed -i 's#2.12.3#2.17.0#g' values.yaml
sed -i 's#kubernetes-helm/tiller#helm/tiller#g' values.yaml
cd ~/dep/ric-dep/helm/appmgr
sed -i 's#gcr.io#ghcr.io#g' values.yaml
sed -i 's#2.12.3#2.17.0#g' values.yaml
sed -i 's#kubernetes-helm/tiller#helm/tiller#g' values.yaml
cd ~
git clone https://gerrit.o-ran-sc.org/r/ric-plt/ric-dep
cp -r ~/ric-dep/helm/3rdparty/influxdb ~/dep/ric-dep/helm/
rm -r ~/ric-dep
mkdir ~/ricdep
cd ~/ricdep
git clone https://gerrit.o-ran-sc.org/r/it/dep
cp ~/ricdep/dep/ric-common/Common-Template/helm/ric-common/templates/_influxdb.tpl  /root/dep/ric-common/Common-Template/helm/ric-common/templates/
rm -r ~/ricdep
cd ~/dep/ric-dep/bin
sed -i 's/alarmadapter/alarmadapter influxdb/g' install

curl -L https://git.io/get_helm.sh | bash
echo "waiting for helm installation"
sleep 60s

cat <<EOB > ~/dep/rbac-config.yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: tiller
  namespace: kube-system
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: tiller
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
  - kind: ServiceAccount
    name: tiller
    namespace: kube-system
EOB

cd ~/dep
kubectl apply -f rbac-config.yaml
helm init --service-account tiller
echo "waiting for helm init"
sleep 30s

kubectl create ns ricinfra
helm install stable/nfs-server-provisioner --namespace ricinfra --name nfs-release-1
kubectl patch storageclass nfs -p '{"metadata": {"annotations":{"storageclass.kubernetes.io/is-default-class":"true"}}}'

echo "waiting for deployment"
sleep 20s

cd ~/dep/bin
./deploy-ric-platform -f ../RECIPE_EXAMPLE/PLATFORM/example_recipe.yaml
EOF
