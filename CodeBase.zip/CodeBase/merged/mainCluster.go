package main

import (
	"fmt"
	"log"
	"net/http"

	"github.com/gorilla/mux"
	"github.com/rs/cors"
)

var router = mux.NewRouter()

func main() {

	go router.HandleFunc("/createVM", createVM).Methods("POST")
	// go router.HandleFunc("/showyaml", showyaml).Methods("GET")
	go router.HandleFunc("/createCluster", createCluster).Methods("POST")
	//	go router.HandleFunc("/createCluster", updateCluster).Methods("POST")
	// go router.HandleFunc("/unregisterACluster", unRegACluster).Methods("PUT")
	go router.HandleFunc("/deleteDeploymentManager", delete).Methods("DELETE")
	// go router.HandleFunc("/deleteAnthosCluster", deleteAnthosCluster).Methods("DELETE")
	// go router.HandleFunc("/clusterAdminRoleBinding", updaterole).Methods("PUT")
	// go router.HandleFunc("/clusterStatus/{ClusterName}", clusterStatus).Methods("GET")
	// go router.HandleFunc("/deploymentManagerStatus/{DepName}", deploymentStatus).Methods("GET")
	// go router.HandleFunc("/addNodePoolAPI", AddNodePoolAPI).Methods("POST")
	// go router.HandleFunc("/horizontalScalingAPI", HorizontalScalingAPI).Methods("POST")
	// go router.HandleFunc("/verticalScalingAPI", VerticalScalingAPI).Methods("POST")
	// go router.HandleFunc("/nodeScalingAPI", NodeScalingAPI).Methods("POST")

	//go router.HandleFunc("/listEndPoints", listEndPoints).Methods("GET")
	c := cors.New(cors.Options{
		AllowedMethods: []string{http.MethodGet, http.MethodPost, http.MethodDelete},
	})
	handler := c.Handler(router)
	fmt.Println("Starting server")
	log.Fatal(http.ListenAndServe(":9003", handler))
}
