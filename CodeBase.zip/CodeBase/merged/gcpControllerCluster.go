package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"net/http"
	"os"
	"os/exec"
	"strconv"
	"strings"

	"gopkg.in/yaml.v3"
)

type ImportsStruct struct {
	Path string `yaml:"path"`
}

type temp_properties struct {
	Imports   []ImportsStruct   `yaml:"imports"`
	Resources []ResourcesStruct `yaml:"resources"`
}

type ResourcesStruct struct {
	Name       string      `yaml:"name"`
	Type       string      `yaml:"type"`
	Properties interface{} `yaml:"properties"`
}

type VMPropertiesStruct struct {
	Region            string `yaml:"region"`
	Zone              string `yaml:"zone"`
	MachineType       string `yaml:"machineType"`
	SourceImageFamily string `yaml:"sourceImageFamily"`
	SourceImage       string `yaml:"sourceImage"`
}

type VeosPropertiesStruct struct {
	Zone           string `yaml:"zone"`
	UserName       string `yaml:"username"`
	SshKey         string `yaml:"sshKey"`
	MachineType    string `yaml:"machineType"`
	Nic0Network    string `yaml:"nic0Net"`
	Nic0Subnetwork string `yaml:"nic0Subnet"`
	Nic1Network    string `yaml:"nic1Net"`
	Nic1Subnetwork string `yaml:"nic1Subnet"`
}

type ClusterPropertiesStruct struct {
	Zone             string `yaml:"zone"`
	InitialNodeCount string `yaml:"initialNodeCount"`
	MachineType      string `yaml:"machineType"`
}

type ResourcesJsonStruct struct {
	Name       string      `json:"name"`
	Type       string      `json:"type"`
	Properties interface{} `json:"properties"`
}

type modification struct {
	DepName   string                `json:"depname"`
	Resources []ResourcesJsonStruct `json:"resources"`
}

func checkErr(err error) {
	if err != nil {
		log.Panic(err)
	}
}

func readDefaultData(Type string) temp_properties {
	fileName := downloadFile(Type)
	yfile, err := ioutil.ReadFile(fileName)
	checkErr(err)
	var properties temp_properties
	err2 := yaml.Unmarshal(yfile, &properties)
	checkErr(err2)
	return properties
}

func downloadFile(Type string) string {
	var fileName string
	fileName = ""
	switch Type {
	case "GKE":
		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/Cluster/*", ".").Run()
		fileName = "cluster-default.yaml"
	case "ABM":
		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/BaremetalCluster/*", ".").Run()
		_ = exec.Command("chmod", "777", "createcluster2.sh").Run()
		_ = exec.Command("chmod", "777", "test.sh").Run()
		_ = exec.Command("chmod", "777", "createnodes.sh").Run()
		_ = exec.Command("chmod", "777", "createnodepool.sh").Run()
	case "ABM-RIC":
		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/RIConCluster/*", ".").Run()
		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/BaremetalCluster/*", ".").Run()
		_ = exec.Command("chmod", "777", "createcluster2.sh").Run()
		_ = exec.Command("chmod", "777", "test.sh").Run()
		_ = exec.Command("chmod", "777", "riconcluster.sh").Run()
	case "VM":
		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/ComputeEngine/*", ".").Run()
		fileName = "compute-engine-template.yaml"
	case "VM-MDB":
		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/ComputeEngineMongoDB/*", ".").Run()
		fileName = "compute-engine-db-template.yaml"
	case "VM-ADB":
		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/ComputeEngineArangoDB/*", ".").Run()
		fileName = "compute-engine-arango-template.yaml"
	case "VM-VEOS":
		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/vEOS/*", ".").Run()
		fileName = "test_config.yaml"
	case "VM-RIC":
		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/ComputeEngineNearRTRIC/*", ".").Run()
		fileName = "compute-engine-ric-template.yaml"
	default:
		log.Fatal("Invalid Input")
	}
	return fileName
}

func structToMapJson(s interface{}) map[string]interface{} {
	var m1 map[string]interface{}
	jsonbody, err := json.Marshal(s)
	checkErr(err)
	err = json.Unmarshal(jsonbody, &m1)
	checkErr(err)
	return m1
}

func structToMapYaml(s interface{}) map[string]interface{} {
	var m1 map[string]interface{}
	yamlbody, err := yaml.Marshal(s)
	checkErr(err)
	err = yaml.Unmarshal(yamlbody, &m1)
	checkErr(err)
	return m1
}

func choosePropertyStruct(Type string) interface{} {
	switch Type {
	case "GKE":
		var cluster ClusterPropertiesStruct
		return cluster
	case "VM":
		var vm VMPropertiesStruct
		return vm
	case "VM-MDB":
		var vm VMPropertiesStruct
		return vm
	case "VM-ADB":
		var vm VMPropertiesStruct
		return vm
	case "VM-VEOS":
		var vEOS VeosPropertiesStruct
		return vEOS
	case "VM-RIC":
		var vm VMPropertiesStruct
		return vm
	default:
		log.Fatal("Invalid Input")
		return nil
	}
}

func createVM(w http.ResponseWriter, r *http.Request) {
	fmt.Println("\nCalled 'Resource Deployment' API")
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	var emptyYamlData temp_properties

	fileName := "running-temp-vm-" + strconv.Itoa(rand.Int()) + ".yaml"
	fh, err := os.Create(fileName)
	checkErr(err)
	fmt.Println("Running template file created")

	var mod modification
	err = json.NewDecoder(r.Body).Decode(&mod)
	checkErr(err)
	fmt.Println("Input Taken")

	f, err := os.Create("CreateLogFile.txt")
	checkErr(err)
	fmt.Println("File Created")

	inputData := "Input:\t" + fmt.Sprintf("%v", mod) + "\n"
	_, err = f.WriteString(inputData)
	checkErr(err)
	fmt.Println("Input Written on file")

	for i, r := range mod.Resources {
		modifyYaml(fh, i, r, &emptyYamlData)
	}

	yml, err := yaml.Marshal(&emptyYamlData)
	checkErr(err)

	_, err = fh.WriteString(string(yml))
	checkErr(err)
	fmt.Println("Data pushed to Running template file")

	cmd := exec.Command("gcloud", "deployment-manager", "deployments", "create", mod.DepName, "--config", fileName)
	var out bytes.Buffer
	cmd.Stdout = &out
	err = cmd.Run()
	checkErr(err)
	fmt.Println("Deployment Created")

	outputData := "Output:\n" + out.String() + "\n"
	_, err = f.WriteString(outputData)
	checkErr(err)
	fmt.Println("Output Written on file")

	fmt.Println("-----------------------------------------------------------")
	fh.Close()
	f.Close()

	json.NewEncoder(w).Encode(out.String())
}

func delete(w http.ResponseWriter, r *http.Request) {
	fmt.Println("Called 'delete' API")
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	type str struct {
		DepName string `json:"depname"`
		Policy  string `json:"deletepolicy"`
	}
	type mod struct {
		Details []str `json:"details"`
	}

	var obj mod
	err := json.NewDecoder(r.Body).Decode(&obj)
	checkErr(err)
	fmt.Println("Input taken for Deletion")

	for i := range obj.Details {
		cmd := exec.Command("gcloud", "deployment-manager", "deployments", "delete", obj.Details[i].DepName, "--delete-policy="+obj.Details[i].Policy, "--quiet")
		var out bytes.Buffer
		cmd.Stdout = &out
		err = cmd.Run()
		checkErr(err)
		fmt.Println("Deployment Deleted")
		fmt.Println("-----------------------------------------------------------")
		json.NewEncoder(w).Encode(out.String())
	}
}

func createCluster(w http.ResponseWriter, r *http.Request) {
	fmt.Println("\nCalled 'Resource Deployment' API")
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	var flag = 0
	var emptyYamlData temp_properties

	fileName := "running-temp-cluster-" + strconv.Itoa(rand.Int()) + ".yaml"
	fh, err := os.Create(fileName)
	checkErr(err)
	fmt.Println("Running template file created")

	var mod modification
	err = json.NewDecoder(r.Body).Decode(&mod)
	checkErr(err)
	fmt.Println("Input Taken")

	f, err := os.Create("CreateLogFile.txt")
	checkErr(err)
	fmt.Println("File Created")

	inputData := "Input:\t" + fmt.Sprintf("%v", mod) + "\n"
	_, err = f.WriteString(inputData)
	checkErr(err)
	fmt.Println("Input Written on file")

	for i, r := range mod.Resources {
		downloadFile(mod.Resources[i].Type)
		if mod.Resources[i].Type == "GKE" {
			flag = 1
			modifyYaml(fh, i, r, &emptyYamlData)
		} else if mod.Resources[i].Type == "ABM" {
			clusterSetupABM(r)
		} else if mod.Resources[i].Type == "ABM-RIC" {
			ricOnCluster(r)
		}
	}

	yml, err := yaml.Marshal(&emptyYamlData)
	checkErr(err)

	_, err = fh.WriteString(string(yml))
	checkErr(err)
	fmt.Println("Data pushed to Running template file")

	if flag == 1 {
		cmd := exec.Command("gcloud", "deployment-manager", "deployments", "create", mod.DepName, "--config", fileName)
		var out bytes.Buffer
		cmd.Stdout = &out
		err = cmd.Run()
		checkErr(err)
		fmt.Println("Deployment Created")

		outputData := "Output:\n" + out.String() + "\n"
		_, err = f.WriteString(outputData)
		checkErr(err)
		fmt.Println("Output Written on file")

		for i := range mod.Resources {
			if mod.Resources[i].Type == "GKE" {
				createAnthosCluster(mod.Resources[i], mod.DepName)
			}
		}

		json.NewEncoder(w).Encode(out.String())
	}
	fmt.Println("-----------------------------------------------------------")
	fh.Close()
	f.Close()

}

// func updateCluster(w http.ResponseWriter, r *http.Request) {
// 	fmt.Println("\nCalled 'Cluster Update' API")
// 	w.Header().Set("Content-Type", "application/json")
// 	w.Header().Set("Access-Control-Allow-Origin", "*")

// 	var flag = 0
// 	//var emptyYamlData temp_properties

// 	// fileName := "running-temp.yaml"
// 	// fh, err := os.Create(fileName)
// 	// checkErr(err)
// 	//fmt.Println("Running template file created")

// 	var mod modification
// 	err := json.NewDecoder(r.Body).Decode(&mod)
// 	checkErr(err)
// 	fmt.Println("Input Taken")

// 	f, err := os.Create("CreateLogFile.txt")
// 	checkErr(err)
// 	fmt.Println("File Created")

// 	inputData := "Input:\t" + fmt.Sprintf("%v", mod) + "\n"
// 	_, err = f.WriteString(inputData)
// 	checkErr(err)
// 	fmt.Println("Input Written on file")

// 	for i, r := range mod.Resources {
// 		downloadFile(mod.Resources[i].Type)
// 		if mod.Resources[i].Type == "GKE" {

// 			//	modifyYamlgke(fh, i, r, &emptyYamlData)
// 		} else if mod.Resources[i].Type == "ABM" {
// 			clusterUpdate(r)
// 		}
// 	}

// 	yml, err := yaml.Marshal(&emptyYamlData)
// 	checkErr(err)

// 	_, err = fh.WriteString(string(yml))
// 	checkErr(err)
// 	fmt.Println("Data pushed to Running template file")

// 	if flag == 1 {
// 		cmd := exec.Command("gcloud", "deployment-manager", "deployments", "create", mod.DepName, "--config", fileName)
// 		var out bytes.Buffer
// 		cmd.Stdout = &out
// 		err = cmd.Run()
// 		checkErr(err)
// 		fmt.Println("Deployment Created")

// 		outputData := "Output:\n" + out.String() + "\n"
// 		_, err = f.WriteString(outputData)
// 		checkErr(err)
// 		fmt.Println("Output Written on file")

// 		for i := range mod.Resources {
// 			if mod.Resources[i].Type == "1" {
// 				createAnthosCluster(mod.Resources[i], mod.DepName)
// 			}
// 		}

// 		json.NewEncoder(w).Encode(out.String())
// 	}
// 	fmt.Println("-----------------------------------------------------------")
// 	fh.Close()
// 	f.Close()

// }

// func modifyYamlVM(fh *os.File, i int, mod ResourcesJsonStruct, emptyYamlData *temp_properties) {
// 	defaultData := readDefaultData(mod.Type)
// 	fmt.Println("Default Data Unmarshalled Successfully")

// 	propsD := structToMapJson(mod.Properties) // modification type

// 	for _, v := range defaultData.Imports {
// 		emptyYamlData.Imports = append(emptyYamlData.Imports, v) //TODO: check for multiple imports in default data
// 	}

// 	var resources ResourcesStruct
// 	resources.Name = mod.Name
// 	resources.Type = defaultData.Resources[0].Type
// 	resources.Properties = choosePropertyStruct(mod.Type)
// 	emptyYamlData.Resources = append(emptyYamlData.Resources, resources)

// 	x := defaultData.Resources[0].Properties
// 	defD := structToMapYaml(x)
// 	ymlD := structToMapYaml(emptyYamlData.Resources[i].Properties)

// 	for property := range ymlD {
// 		if propsD[property] != nil {
// 			ymlD[property] = propsD[property]
// 		} else {
// 			ymlD[property] = defD[property]
// 		}
// 	}

// 	jsonbody, err := json.Marshal(ymlD)
// 	checkErr(err)

// 	err = json.Unmarshal(jsonbody, &emptyYamlData.Resources[i].Properties)
// 	checkErr(err)
// }

func modifyYaml(fh *os.File, i int, mod ResourcesJsonStruct, emptyYamlData *temp_properties) {
	//defaultData := readDefaultData(mod.Type)
	defaultData := readDefaultData(mod.Type)
	fmt.Println("Default Data Unmarshalled Successfully")

	propsD := structToMapJson(mod.Properties) // modification type

	for _, v := range defaultData.Imports {
		emptyYamlData.Imports = append(emptyYamlData.Imports, v) //TODO: check for multiple imports in default data
	}

	var resources ResourcesStruct
	resources.Name = mod.Name
	resources.Type = defaultData.Resources[0].Type
	resources.Properties = choosePropertyStruct(mod.Type)
	emptyYamlData.Resources = append(emptyYamlData.Resources, resources)

	x := defaultData.Resources[0].Properties
	defD := structToMapYaml(x)
	ymlD := structToMapYaml(emptyYamlData.Resources[i].Properties)

	for property := range ymlD {
		if propsD[property] != nil {
			ymlD[property] = propsD[property]
		} else {
			ymlD[property] = defD[property]
		}
	}

	jsonbody, err := json.Marshal(ymlD)
	checkErr(err)

	err = json.Unmarshal(jsonbody, &emptyYamlData.Resources[i].Properties)
	checkErr(err)
}

func ricOnCluster(inp ResourcesJsonStruct) {
	abm := structToMapJson(inp.Properties)
	Zone := abm["zone"].(string)
	clusterSetupABM(inp)
	cmd := exec.Command("./riconcluster.sh", inp.Name+"-ws", Zone, inp.Name+"-wn1")
	// var outb, errb bytes.Buffer
	// cmd.Stdout = &outb
	//err := cmd.Run()
	stdout2, _ := cmd.StdoutPipe()
	//fmt.Println("Creating Cluster...")
	err := cmd.Start()
	checkErr(err)

	// //var oneByte2 []byte

	for {
		oneByte2 := make([]byte, 500)
		_, err := stdout2.Read(oneByte2)
		if err != nil {
			break
		}
		fmt.Println(string(oneByte2))
		oneByte2 = nil
	}
	if err != nil {
		fmt.Println(err.Error())
		return
	}
	fmt.Println("Near RT RIC is been deployed on the cluster")
}

func clusterSetupABM(inp ResourcesJsonStruct) {
	abm := structToMapJson(inp.Properties)

	Zone := abm["zone"].(string)
	MachineType := abm["machineType"].(string)
	SubNet1 := abm["subnet1"].(string)
	SubNet2 := abm["subnet2"].(string)
	SubNet3 := abm["subnet3"].(string)
	DiskSize := abm["disksize"].(string)
	NumNodes := abm["numnodes"].(string)

	var vms []string
	i := 0
	vms = append(vms, inp.Name+"-ws")
	vms = append(vms, inp.Name+"-cp")
	val, _ := strconv.Atoi(NumNodes)
	for i < val {
		vms = append(vms, (inp.Name + "-wn" + strconv.Itoa(i+1)))
		i += 1
	}
	log.Println(vms)

	vmsjoin := strings.Join(vms, " ")
	fmt.Println("After joining VMs names: ", vmsjoin)

	cmd := "./test.sh --zone=" + Zone + " --machinetype=" + MachineType + " --prefix=" + inp.Name + " --vms='" + vmsjoin + "' --subnet1=" + SubNet1 + " --subnet2=" + SubNet2 + " --subnet3=" + SubNet3 + " --disksize=" + DiskSize
	fmt.Println(cmd)
	cmd1 := exec.Command("bash", "-c", cmd)
	stdout, _ := cmd1.StdoutPipe()
	err := cmd1.Start()
	checkErr(err)

	for {
		oneByte := make([]byte, 700)
		_, err := stdout.Read(oneByte)
		if err != nil {
			break
		}
		fmt.Println(string(oneByte))
		oneByte = nil
	}

	log.Println("VMs Setup Sucessfull")

	var nodesmap []string
	key := "{address: 10.200.0."
	i = 0
	// [{address: 10.200.0.4},{address: 10.200.0.5}]

	for i < val {

		nodesmap = append(nodesmap, key+strconv.Itoa(i+4)+"}")
		i += 1
	}
	fmt.Println("Worker node-array is: ", nodesmap)
	nodes := strings.Join(nodesmap, ",")
	nodes = "[" + nodes + "]"
	fmt.Println("Worker node-array is: ", nodes)

	cmd = "./createcluster2.sh  --zone=" + Zone + " --nodesaddr='" + nodes + "' --prefix=" + inp.Name + " --clusterid=" + inp.Name + " --region=" + strings.Join(strings.Split(Zone, "-")[:2], "-")
	log.Println(cmd)

	cmd1 = exec.Command("bash", "-c", cmd)

	stdout2, _ := cmd1.StdoutPipe()
	fmt.Println("Creating Cluster...")
	err = cmd1.Start()
	checkErr(err)

	// //var oneByte2 []byte

	for {
		oneByte2 := make([]byte, 700)
		_, err := stdout2.Read(oneByte2)
		if err != nil {
			break
		}
		fmt.Println(string(oneByte2))
		oneByte2 = nil
	}
}

// func clusterUpdate(inp ResourcesJsonStruct) {
// 	fmt.Println("\nCalled 'Cluster Update' API")

// 	abm := structToMapJson(inp.Properties)

// 	Zone := abm["zone"].(string)
// 	MachineType := abm["machineType"].(string)
// 	SubNet1 := abm["subnet1"].(string)
// 	SubNet2 := abm["subnet2"].(string)
// 	SubNet3 := abm["subnet3"].(string)
// 	DiskSize := abm["disksize"].(string)
// 	NumNodes := abm["numnodes"].(string)
// 	NewNodes := abm["newnodes"].(string)
// 	NodepoolName := abm["nodepoolname"].(string)
// 	var vms []string
// 	i := 0
// 	//log.Println("appending vms")
// 	vms = append(vms, inp.Name+"-ws")
// 	//log.Println("appending vms 2")
// 	vms = append(vms, inp.Name+"-cp")
// 	val1, _ := strconv.Atoi(NumNodes)
// 	val2, _ := strconv.Atoi(NewNodes)
// 	for i < val1+val2 {
// 		vms = append(vms, (inp.Name + "-wn" + strconv.Itoa(i+1)))
// 		i += 1
// 	}
// 	log.Println(vms)

// 	vmsjoin := strings.Join(vms, " ")
// 	fmt.Println("Existing VMs names: ", vmsjoin)

// 	newvms := strings.Join(vms[val1+2:], " ")
// 	fmt.Println("New nodes are: ", newvms)

// 	cmd := "./createnodes.sh --zone=" + Zone + " --machinetype=" + MachineType + " --prefix=" + inp.Name + " --vms='" + vmsjoin + "' --newvms='" + newvms + "' --subnet1=" + SubNet1 + " --subnet2=" + SubNet2 + " --subnet3=" + SubNet3 + " --disksize=" + DiskSize
// 	fmt.Println(cmd)
// 	cmd1 := exec.Command("bash", "-c", cmd)
// 	stdout, _ := cmd1.StdoutPipe()
// 	err := cmd1.Start()
// 	checkErr(err)
// 	//var oneByte []byte
// 	oneByte := make([]byte, 1000)
// 	for {
// 		_, err := stdout.Read(oneByte)
// 		if err != nil {
// 			break
// 		}
// 		fmt.Println(string(oneByte))
// 	}

// 	log.Println("New VMs Setup Sucessfull")

// 	var nodesmap []string
// 	key := "{address: 10.200.0."
// 	i = val1
// 	// [{address: 10.200.0.4},{address: 10.200.0.5}]
// 	for i < val1+val2 {

// 		nodesmap = append(nodesmap, key+strconv.Itoa(i+4)+"}")
// 		i += 1
// 	}
// 	fmt.Println("Worker node-array is: ", nodesmap)
// 	nodes := strings.Join(nodesmap, ",")
// 	nodes = "[" + nodes + "]"
// 	fmt.Println("Worker node-array is: ", nodes)

// 	cmd = "./createnodepool.sh  --zone=" + Zone + " --nodepool=" + NodepoolName + " --nodesaddr='" + nodes + "' --prefix=" + inp.Name + " --clusterid=" + inp.Name + " --region=" + strings.Join(strings.Split(Zone, "-")[:2], "-")
// 	log.Println(cmd)

// 	cmd1 = exec.Command("bash", "-c", cmd)

// 	stdout2, _ := cmd1.StdoutPipe()
// 	fmt.Println("Updating Cluster...")
// 	err = cmd1.Start()
// 	checkErr(err)

// 	oneByte2 := make([]byte, 1000)
// 	for {
// 		_, err := stdout2.Read(oneByte2)
// 		if err != nil {
// 			break
// 		}
// 		fmt.Println(string(oneByte2))

// 	}

// 	fmt.Println("Nodepool Added Successfully")
// }

func createAnthosCluster(mod ResourcesJsonStruct, DepName string) {
	anthos := structToMapJson(mod.Properties)

	fmt.Println("Entered Anthos Registration:")
	fmt.Println("Config-Management - ", anthos["configManagement"].(string))
	fmt.Println("App-Service-Mesh - ", anthos["appServiceMesh"].(string))

	ClusterName := mod.Name
	Projectid := anthos["projectid"].(string)
	Zone := anthos["zone"].(string)

	cmd1 := exec.Command("gcloud", "container", "clusters", "get-credentials", ClusterName, "--zone", Zone, "--project", Projectid)
	err := cmd1.Run()
	if err != nil {
		fmt.Println(err.Error(), DepName+" - Getting credentials failed")
		return
	}
	fmt.Println(DepName, " - Gettting credentials successful!")

	if anthos["configManagement"].(string) == "true" {
		cmdwli := exec.Command("gcloud", "container", "clusters", "update", ClusterName, "--workload-pool="+Projectid+".svc.id.goog")
		err := cmdwli.Run()
		if err != nil {
			fmt.Println(err.Error(), DepName+" - Enabling work load identity failed")
			return
		}
		fmt.Println(DepName, " - Enabling work load identity successful!")

		cmdfleet := exec.Command("gcloud", "container", "hub", "memberships", "register", ClusterName, "--gke-cluster="+Zone+"/"+ClusterName, "--enable-workload-identity")
		err = cmdfleet.Run()
		if err != nil {
			fmt.Println(err.Error(), DepName+" - Fleet registration failed")
			return
		}
		fmt.Println(DepName, " - Fleet registration successful!")

		//-------------------------------------

		cmdcr := exec.Command("kubectl", "create", "ns", "config-management-system")
		err = cmdcr.Run()
		if err != nil {
			fmt.Println(err.Error(), DepName, " - Namespace creation for config-management failed")
			return
		}
		fmt.Println(DepName, " - Namespace creation for config-management successful!")

		cmdkey := exec.Command("kubectl", "create", "secret", "generic", "git-creds", "--namespace=config-management-system", "--from-file=ssh=/data/ashir/.ssh/id_rsa")
		err = cmdkey.Run()
		if err != nil {
			fmt.Println(err.Error(), DepName, " - Secret generation failed")
			return
		}
		fmt.Println(DepName, " - Secret generation successful!")

		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/Config-Management/*", ".").Run()
		cmdanthos := exec.Command("gcloud", "beta", "container", "hub", "config-management", "apply", "--membership="+ClusterName, "--config=apply-spec.yaml", "--project="+Projectid)
		err = cmdanthos.Run()
		if err != nil {
			fmt.Println(err.Error(), DepName+" - Configuring Config management failed")
			return
		}
		fmt.Println(DepName, " - Configuration of anthos config management successful!")
	}
	//-------------------------------------
	if anthos["appServiceMesh"].(string) == "true" {
		cmd5 := exec.Command("./asmcli", "install", "--project_id", Projectid, "--cluster_name", ClusterName, "--cluster_location", Zone, "--fleet_id", Projectid, "--output_dir", "asm", "--enable_all", "--ca", "mesh_ca", "--revision_name", "asm-label")
		err := cmd5.Run()
		if err != nil {
			fmt.Println(err.Error(), DepName+" - Failed to install asm")
			return
		}
		fmt.Println(DepName, " - ASM cli installation successful!")

		for _, name := range anthos["namespace"].(string) {
			cmd2 := exec.Command("kubectl", "create", "namespace", string(name))
			err = cmd2.Run()
			if err != nil {
				fmt.Println(err.Error())
			}
			fmt.Println(DepName, " - Namespace creation for ASM successful!")
		}

		for _, name := range anthos["namespace"].(string) {
			cmd4 := exec.Command("kubectl", "label", "namespace", string(name), "istio-injection-", "istio.io/rev=asm-label", "--overwrite")
			fmt.Println(cmd4)
			err = cmd4.Run()
			if err != nil {
				fmt.Println(err.Error(), DepName+" - Failed to enable auto injection")
				return
			}
			fmt.Println(DepName, " - Enable Auto injection successfull!")
		}

		fmt.Println("Done registering the cluster")
	}
}

func kubeNamespace(mod ResourcesJsonStruct) {
	fmt.Println("Entered Namespace Creation")
	depmap := structToMapJson(mod.Properties)

	cmd1 := exec.Command("gcloud", "container", "clusters", "get-credentials", depmap["clusterName"].(string), "--zone", depmap["zone"].(string))
	err := cmd1.Run()
	if err != nil {
		fmt.Println(err.Error(), " - getting credentials failed")
		return
	}
	fmt.Println("getting clusters credentials successful!")

	cmd2 := exec.Command("kubectl", "create", "namespace", depmap["namespace"].(string))
	err = cmd2.Run()
	if err != nil {
		fmt.Println(err.Error(), " - namespace creation failed")
		return
	}
	fmt.Println("namespace creation successful!")
}

func AddNodePool(mod ResourcesJsonStruct) bytes.Buffer {
	fmt.Println("Entered NodePool Addition")

	//machine type, disk-size, node-locations, num-nodes
	depmap := structToMapJson(mod.Properties)
	fmt.Println("StructToMapJson done")
	if (depmap["region"] != nil && depmap["zone"] != nil) || (depmap["region"] == nil && depmap["zone"] == nil) {
		log.Panic("Give either zone or region, based on zonal or regional cluster")
	}
	var command string = "gcloud container node-pools create " + mod.Name + " --cluster=" + depmap["clusterName"].(string) // +" --region="+depmap["region"].(string)
	fmt.Println("Command = : ", command)
	if depmap["machineType"].(string) != "" {
		command += " --machine-type=" + depmap["machineType"].(string)
	}
	fmt.Println("Command = : ", command)
	if depmap["diskSize"].(string) != "" {
		command += " --disk-size=" + depmap["diskSize"].(string)
	}
	fmt.Println("Command = : ", command)
	if depmap["numNodes"].(string) != "" {
		command += " --num-nodes=" + depmap["numNodes"].(string)
	}
	fmt.Println("Command = : ", command)
	if depmap["nodeLocations"] != nil {
		command += " --node-locations="
		for _, v := range depmap["nodeLocations"].([]interface{}) {
			command += v.(string) + ","
		}
		command = command[:len(command)-1]
	}
	if depmap["region"] != nil {
		command += " --region=" + depmap["region"].(string)
	} else {
		command += " --zone=" + depmap["zone"].(string)
	}
	fmt.Println("Command = : ", command)
	cmd1 := exec.Command("bash", "-c", command)
	var out bytes.Buffer
	cmd1.Stdout = &out
	err := cmd1.Run()
	checkErr(err)
	fmt.Println(out.String())
	return out
}

func AddNodePoolAPI(w http.ResponseWriter, r *http.Request) {
	fmt.Println("\nCalled 'Add Node Pool' API")
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	var mod ResourcesJsonStruct
	err := json.NewDecoder(r.Body).Decode(&mod)
	checkErr(err)
	fmt.Println("Input Taken")

	out := AddNodePool(mod)
	json.NewEncoder(w).Encode(out.String())

}

func HorizontalScaling(mod ResourcesJsonStruct) string {
	// For Horizontal Pod Autoscaling
	fmt.Println("Entered HorizontalScaling")

	//deploymentname,cpu-utilization, minpods,maxpods
	depmap := structToMapJson(mod.Properties)
	fmt.Println("StructToMapJson done")

	if (depmap["region"] != nil && depmap["zone"] != nil) || (depmap["region"] == nil && depmap["zone"] == nil) {
		log.Panic("Give either zone or region, based on zonal or regional cluster")
		return "100"
	}
	var command1 string = "gcloud container clusters get-credentials " + depmap["clusterName"].(string)
	if depmap["region"].(string) != "" {
		command1 += " --region=" + depmap["region"].(string)
	} else {
		command1 += " --zone=" + depmap["zone"].(string)
	}
	fmt.Println(command1)
	cmd := exec.Command("bash", "-c", command1)
	err := cmd.Run()
	if err != nil {
		fmt.Println(err.Error(), " - getting credentials failed")
		return "100"
	}
	fmt.Println("getting clusters credentials successful!")

	var command2 string = "kubectl autoscale deployment " + depmap["deploymentName"].(string) + " --max=" + depmap["maxPods"].(string)
	if depmap["cpuPercent"] != nil {
		command2 += " --cpu-percent=" + depmap["cpuPercent"].(string)
	}
	if depmap["minPods"] != nil {
		command2 += " --min=" + depmap["minPods"].(string)
	}
	fmt.Println(command2)
	cmd2 := exec.Command("bash", "-c", command2)
	err = cmd2.Run()
	if err != nil {
		fmt.Println(err.Error(), " - could not autoscale pods horizontally")
		return "100"
	}
	return "101"
}

func HorizontalScalingAPI(w http.ResponseWriter, r *http.Request) {
	fmt.Println("\nCalled 'HPA' API")
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	var mod ResourcesJsonStruct
	err := json.NewDecoder(r.Body).Decode(&mod)
	checkErr(err)
	fmt.Println("Input Taken")

	out := HorizontalScaling(mod)
	if out == "100" {
		json.NewEncoder(w).Encode("Error in Horizontal Autoscaling")
	} else {
		json.NewEncoder(w).Encode("HPA Created")
	}
}

func VerticalScaling(mod ResourcesJsonStruct) string {
	depmap := structToMapJson(mod.Properties)
	fmt.Println("StructToMapJson done")

	if (depmap["region"] != nil && depmap["zone"] != nil) || (depmap["region"] == nil && depmap["zone"] == nil) {
		log.Panic("Give either zone or region, based on zonal or regional cluster")
		return "100"
	}
	var command1 string = "gcloud container clusters update " + depmap["clusterName"].(string) + " --enable-vertical-pod-autoscaling"
	if depmap["region"].(string) != "" {
		command1 += " --region=" + depmap["region"].(string)
	} else {
		command1 += " --zone=" + depmap["zone"].(string)
	}
	fmt.Println(command1)
	cmd := exec.Command("bash", "-c", command1)
	err := cmd.Run()
	if err != nil {
		fmt.Println(err.Error(), " - could not autoscale pods vertically")
		return "100"
	}
	return "101"
}

func VerticalScalingAPI(w http.ResponseWriter, r *http.Request) {
	fmt.Println("\nCalled 'VPA' API")
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	var mod ResourcesJsonStruct
	err := json.NewDecoder(r.Body).Decode(&mod)
	checkErr(err)
	fmt.Println("Input Taken")

	out := VerticalScaling(mod)
	if out == "100" {
		json.NewEncoder(w).Encode("Error in Vertical Autoscaling")
	} else {
		json.NewEncoder(w).Encode("VPA Created")
	}

}

func NodeScaling(mod ResourcesJsonStruct) string {
	depmap := structToMapJson(mod.Properties)
	fmt.Println("StructToMapJson done")

	if (depmap["region"] != nil && depmap["zone"] != nil) || (depmap["region"] == nil && depmap["zone"] == nil) {
		log.Panic("Give either zone or region, based on zonal or regional cluster")
		return "100"
	}
	var command1 string = "gcloud container clusters update " + depmap["clusterName"].(string) + " --enable-autoscaling" + " --node-pool " + depmap["nodePool"].(string) + " --max-nodes " + depmap["maxNodes"].(string)
	if depmap["region"].(string) != "" {
		command1 += " --region=" + depmap["region"].(string)
	} else {
		command1 += " --zone=" + depmap["zone"].(string)
	}
	if depmap["minNodes"].(string) != "" {
		command1 += " --min-nodes " + depmap["minNodes"].(string)
	}

	fmt.Println(command1)
	cmd := exec.Command("bash", "-c", command1)
	err := cmd.Run()
	if err != nil {
		fmt.Println(err.Error(), " - could not autoscale Nodes")
		return "100"
	}
	return "101"
}

func NodeScalingAPI(w http.ResponseWriter, r *http.Request) {
	fmt.Println("\nCalled 'Node Autoscaling' API")
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	var mod ResourcesJsonStruct
	err := json.NewDecoder(r.Body).Decode(&mod)
	checkErr(err)
	fmt.Println("Input Taken")

	out := NodeScaling(mod)
	if out == "100" {
		json.NewEncoder(w).Encode("Error in Node Autoscaling")
	} else {
		json.NewEncoder(w).Encode("Node Autoscaling Done")
	}
}

////////////////////////////////////////////////////////////////////////
