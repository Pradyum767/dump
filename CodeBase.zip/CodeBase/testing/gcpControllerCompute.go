package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"os/exec"
	"gopkg.in/yaml.v3"
)

type ImportsStruct struct {
	Path string `yaml:"path"`
}

type temp_properties struct {
	Imports   []ImportsStruct   `yaml:"imports"`
	Resources []ResourcesStruct `yaml:"resources"`
}

type ResourcesStruct struct {
	Name       string      `yaml:"name"`
	Type       string      `yaml:"type"`
	Properties interface{} `yaml:"properties"`
}

type VMPropertiesStruct struct {
	Region            string `yaml:"region"`
	Zone              string `yaml:"zone"`
	MachineType       string `yaml:"machineType"`
	SourceImageFamily string `yaml:"sourceImageFamily"`
	SourceImage       string `yaml:"sourceImage"`
}

type VeosPropertiesStruct struct {
	Zone           string `yaml:"zone"`
	UserName       string `yaml:"username"`
	SshKey         string `yaml:"sshKey"`
	MachineType    string `yaml:"machineType"`
	Nic0Network    string `yaml:"nic0Net"`
	Nic0Subnetwork string `yaml:"nic0Subnet"`
	Nic1Network    string `yaml:"nic1Net"`
	Nic1Subnetwork string `yaml:"nic1Subnet"`
}

type ResourcesJsonStruct struct {
	Name       string      `json:"name"`
	Type       string      `json:"type"`
	Properties interface{} `json:"properties"`
}

type modification struct {
	DepName   string                `json:"depname"`
	Resources []ResourcesJsonStruct `json:"resources"`
}

func checkErr(err error) {
	if err != nil {
		log.Panic(err)
	}
}

func readDefaultDataVM(Type string) temp_properties {
	fileName := chooseFileVM(Type)
	yfile, err := ioutil.ReadFile(fileName)
	checkErr(err)
	var properties temp_properties
	err2 := yaml.Unmarshal(yfile, &properties)
	checkErr(err2)
	return properties
}

func chooseFileVM(Type string) string {
	var fileName string
	switch Type {
	case "1":
		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/ComputeEngine/*", ".").Run()
		fileName = "compute-engine-template.yaml"
	case "2":
		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/ComputeEngineMongoDB/*", ".").Run()
		fileName = "compute-engine-db-template.yaml"
	case "3":
		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/ComputeEngineArangoDB/*", ".").Run()
		fileName = "compute-engine-arango-template.yaml"
	case "4":
		_ = exec.Command("gsutil", "cp", "gs://edgescalar-deployment-files/vEOS/*", ".").Run()
		fileName = "test_config.yaml"
	case "5":
		_= exec.Command("gsutil","cp","gs://edgescalar-deployment-files/ComputeEngineNearRTRIC/*",".").Run()
		fileName = "compute-engine-ric-template.yaml"
	default:
		log.Fatal("Invalid Input")
	}
	return fileName
}

func structToMapJsonVM(s interface{}) map[string]interface{} {
	var m1 map[string]interface{}
	jsonbody, err := json.Marshal(s)
	checkErr(err)
	err = json.Unmarshal(jsonbody, &m1)
	checkErr(err)
	return m1
}

func structToMapYamlVM(s interface{}) map[string]interface{} {
	var m1 map[string]interface{}
	yamlbody, err := yaml.Marshal(s)
	checkErr(err)
	err = yaml.Unmarshal(yamlbody, &m1)
	checkErr(err)
	return m1
}

func choosePropertyStructVM(Type string) interface{} {
	switch Type {
	case "1":
		var vm VMPropertiesStruct
		return vm
	case "2":
		var vm VMPropertiesStruct
		return vm
	case "3":
		var vm VMPropertiesStruct
		return vm
	case "4":
		var vEOS VeosPropertiesStruct
		return vEOS
	case "5":
		var vm VMPropertiesStruct
		return vm
	default:
		log.Fatal("Invalid Input")
		return nil
	}
}

func createVM(w http.ResponseWriter, r *http.Request) {
	fmt.Println("\nCalled 'Resource Deployment' API")
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	var emptyYamlData temp_properties

	fileName := "running-temp.yaml"
	fh, err := os.Create(fileName)
	checkErr(err)
	fmt.Println("Running template file created")

	var mod modification
	err = json.NewDecoder(r.Body).Decode(&mod)
	checkErr(err)
	fmt.Println("Input Taken")

	f, err := os.Create("CreateLogFile.txt")
	checkErr(err)
	fmt.Println("File Created")

	inputData := "Input:\t" + fmt.Sprintf("%v", mod) + "\n"
	_, err = f.WriteString(inputData)
	checkErr(err)
	fmt.Println("Input Written on file")

	for i, r := range mod.Resources {
		modifyYamlVM(fh, i, r, &emptyYamlData)
	}

	yml, err := yaml.Marshal(&emptyYamlData)
	checkErr(err)

	_, err = fh.WriteString(string(yml))
	checkErr(err)
	fmt.Println("Data pushed to Running template file")

	cmd := exec.Command("gcloud", "deployment-manager", "deployments", "create", mod.DepName, "--config", fileName)
	var out bytes.Buffer
	cmd.Stdout = &out
	err = cmd.Run()
	checkErr(err)
	fmt.Println("Deployment Created")

	outputData := "Output:\n" + out.String() + "\n"
	_, err = f.WriteString(outputData)
	checkErr(err)
	fmt.Println("Output Written on file")

	fmt.Println("-----------------------------------------------------------")
	fh.Close()
	f.Close()

	json.NewEncoder(w).Encode(out.String())
}

func deleteVM(w http.ResponseWriter, r *http.Request) {
	fmt.Println("Called 'delete' API")
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	type str struct {
		DepName string `json:"depname"`
		Policy  string `json:"deletepolicy"`
	}
	type mod struct {
		Details []str `json:"details"`
	}

	var obj mod
	err := json.NewDecoder(r.Body).Decode(&obj)
	checkErr(err)
	fmt.Println("Input taken for Deletion")

	for i := range obj.Details {
		cmd := exec.Command("gcloud", "deployment-manager", "deployments", "delete", obj.Details[i].DepName, "--delete-policy="+obj.Details[i].Policy, "--quiet")
		var out bytes.Buffer
		cmd.Stdout = &out
		err = cmd.Run()
		checkErr(err)
		fmt.Println("Deployment Deleted")
		fmt.Println("-----------------------------------------------------------")
		json.NewEncoder(w).Encode(out.String())
	}
}

func modifyYamlVM(fh *os.File, i int, mod ResourcesJsonStruct, emptyYamlData *temp_properties) {
	defaultData := readDefaultDataVM(mod.Type)
	fmt.Println("Default Data Unmarshalled Successfully")

	propsD := structToMapJsonVM(mod.Properties) // modification type

	for _, v := range defaultData.Imports {
		emptyYamlData.Imports = append(emptyYamlData.Imports, v) //TODO: check for multiple imports in default data
	}

	var resources ResourcesStruct
	resources.Name = mod.Name
	resources.Type = defaultData.Resources[0].Type
	resources.Properties = choosePropertyStructVM(mod.Type)
	emptyYamlData.Resources = append(emptyYamlData.Resources, resources)

	x := defaultData.Resources[0].Properties
	defD := structToMapYamlVM(x)
	ymlD := structToMapYamlVM(emptyYamlData.Resources[i].Properties)

	for property := range ymlD {
		if propsD[property] != nil {
			ymlD[property] = propsD[property]
		} else {
			ymlD[property] = defD[property]
		}
	}

	jsonbody, err := json.Marshal(ymlD)
	checkErr(err)

	err = json.Unmarshal(jsonbody, &emptyYamlData.Resources[i].Properties)
	checkErr(err)
}
