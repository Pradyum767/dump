package main

import (
        "log"
        "net/http"
        "fmt"

        "github.com/gorilla/mux"
        "github.com/rs/cors"
)

var router = mux.NewRouter()

func main() {
        router.HandleFunc("/createvm", createVM).Methods("POST")
        c := cors.New(cors.Options{
                AllowedMethods: []string{http.MethodGet, http.MethodPost, http.MethodDelete},
        })
        handler := c.Handler(router)
        fmt.Println("Starting resource creation server")
        log.Fatal(http.ListenAndServe(":8880", handler))
}